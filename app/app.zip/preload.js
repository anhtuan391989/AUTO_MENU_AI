const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("electronAPI", {
    // ---- Setup window ----
    openSetup: () => ipcRenderer.send("open-setup"),
    closeSetup: () => ipcRenderer.send("close-setup"),
    notifySetupChanged: () => ipcRenderer.send("setup-changed"),

    // ---- TASK B3-C: báo cáo Manual State THẬT (Key/Mod override) lên Core, KHÔNG polling —
    // chỉ gọi khi state thực sự đổi (xem ui/js/renderer.js, hàm reportManualStateSnapshot). ----
    reportManualState: (snapshot) => ipcRenderer.send("report-manual-state", snapshot),
    onSetupChanged: (callback) => ipcRenderer.on("setup-changed", () => callback()),

    // ---- Kiểm tra kết nối main process ----
    ping: () => ipcRenderer.invoke("ping"),

    // ---- AutoHotkey / lấy toạ độ ----
    findAhkPath: () => ipcRenderer.invoke("find-ahk-path"),
    setupCapture: (payload) => ipcRenderer.invoke("setup-capture", payload),
    downloadAhk: () => ipcRenderer.invoke("download-ahk"),
    clickAtPoint: (point) => ipcRenderer.invoke("click-at-point", point),

    // ---- Tải & cài phần mềm ----
    downloadAndInstall: (url, label) => ipcRenderer.invoke("download-and-install", { url, label }),
    downloadBrave: () => ipcRenderer.invoke("download-brave"),
    downloadVst2: (url) => ipcRenderer.invoke("download-vst2", url),
    openExternalUrl: (url) => ipcRenderer.invoke("open-external-url", url),

    // ---- Trình duyệt ----
    findBrowserPath: (browserName) => ipcRenderer.invoke("find-browser-path", browserName),

    // ---- TASK B30.2: kiểm tra 1 đường dẫn file có còn tồn tại thật trên đĩa không (dùng cho
    // Setup re-validate selectedBrowserPath sau khi lưu) ----
    checkPathExists: (filePath) => ipcRenderer.invoke("check-path-exists", filePath),

    // ---- TASK A55: phân biệt path là FILE thật (không phải thư mục) — dùng để validate DAW
    // Executable Path trong nhóm Startup & Paths ----
    checkPathIsFile: (filePath) => ipcRenderer.invoke("check-path-is-file", filePath),

    // ---- Cài đặt lưu trên file (thay localStorage) ----
    loadSettingsSync: () => ipcRenderer.sendSync("load-settings-sync"),
    saveSettingsSync: (data) => ipcRenderer.sendSync("save-settings-sync", data),

    // ---- File / backup ----
    selectFile: (options) => ipcRenderer.invoke("select-file", options),
    exportBackup: (data) => ipcRenderer.invoke("export-backup", data),
    importBackup: () => ipcRenderer.invoke("import-backup"),

    // ---- Mở DAW / project / youtube cùng lúc ----
    openProjectBundle: (options) => ipcRenderer.invoke("open-project-bundle", options),

    // ---- Tính năng AI (mới thêm) ----
    // Lưu ý: main.js hiện CHƯA có ipcMain.handle("ai-command", ...).
    // Cần nối phần AI layer + Command Engine vào main.js thì hàm này mới chạy được.
    sendCommand: (text) => ipcRenderer.invoke("ai-command", text),

    // ---- Gửi kết quả Key/BPM/MOD từ engine (ui/js/engines/*) sang Core (AIContext) ----
    // type: "key" | "bpm" | "mod", payload: dữ liệu tương ứng (xem app/main.js: ipcMain.on("ai-result"))
    reportAiResult: (type, payload) => ipcRenderer.send("ai-result", { type, payload }),

    // ---- Bridge: nhận lệnh Plugin trừu tượng từ Core (PluginController) ----
    // callback nhận { command, value, confidence, reason, timestamp } — renderer tự quyết
    // định gọi hàm nào trong vocalCommandRouter.js tương ứng với command.
    onPluginCommand: (callback) => ipcRenderer.on("plugin-command", (event, message) => callback(message)),

    // ---- Control Source: LEGACY_CONTROL hay AI_CONTROL (xem core/shared/ControlSource.js) ----
    getControlSource: () => ipcRenderer.invoke("get-control-source"),

    // ---- Now Playing (WindowsMediaSession -> Renderer, chỉ đẩy khi có event thật) ----
    // snapshot: { application, title, artist, album, thumbnail, timestamp } | null
    onNowPlayingChange: (callback) => ipcRenderer.on("now-playing-change", (event, snapshot) => callback(snapshot)),
    // info: { reason, message? } — xem core/integration/WindowsMediaSession.js, event "unavailable"
    onNowPlayingUnavailable: (callback) => ipcRenderer.on("now-playing-unavailable", (event, info) => callback(info)),

    // ---- Telemetry (Phase 4A): gửi 1 bản ghi JSON sang main process để ghi vào logs/*.jsonl ----
    // Fire-and-forget, không cần phản hồi — giống cơ chế reportAiResult đã có.
    sendTelemetry: (record) => ipcRenderer.send("telemetry-record", record),

    // ---- UI FINAL v2.0: "Menu ôm sát nội dung" — CHỈ đổi chiều cao cửa sổ chính ----
    resizeWindow: (height) => ipcRenderer.send("resize-window", { height }),

    // ---- TASK B — MENU RUNTIME: thu nhỏ cửa sổ chính thật (thay console.log("MINIMIZE")) ----
    minimizeWindow: () => ipcRenderer.send("minimize-window"),

    // ---- MENU-UI-01B — Always on Top: main trả về { ok, value, error? } với value = trạng thái THẬT ----
    getAlwaysOnTop: () => ipcRenderer.invoke("get-always-on-top"),
    setAlwaysOnTop: (enabled) => ipcRenderer.invoke("set-always-on-top", enabled),

    // ---- BẢNG HIỆU ỨNG ĐỘC LẬP (cửa sổ riêng, xem app/EffectsWindow.js) ----
    toggleEffectsWindow: () => ipcRenderer.send("effects-toggle"),
    closeEffectsWindow: () => ipcRenderer.send("effects-close"),
    getEffectsAlwaysOnTop: () => ipcRenderer.invoke("effects-get-aot"),
    setEffectsAlwaysOnTop: (enabled) => ipcRenderer.invoke("effects-set-aot", enabled),
    // Nút trong Bảng Hiệu Ứng -> main -> cửa sổ menu (nơi có SoundEffectEngine). effectId: "CLAP" | "LAUGH"
    playEffect: (effectId) => ipcRenderer.send("effects-play", effectId),
    onEffectsPlay: (callback) => ipcRenderer.on("effects-play", (event, effectId) => callback(effectId)),

    // ---- THƯ VIỆN HIỆU ỨNG (bảng nhiều nút + mục "Hiệu Ứng" trong Cài đặt, xem app/EffectsLibrary.js) ----
    getEffectsLibrary: () => ipcRenderer.invoke("effects-lib-get"),
    effectsLibraryOp: (op) => ipcRenderer.invoke("effects-lib-op", op),
    playLibEffect: (id) => ipcRenderer.send("effects-lib-play", id),
    stopLibEffects: () => ipcRenderer.send("effects-lib-stop"),
    openEffectsEditor: () => ipcRenderer.send("effects-open-editor"),
    onEffectsLibChanged: (callback) => ipcRenderer.on("effects-lib-changed", (event, items) => callback(items)),
    onEffectsLibPlay: (callback) => ipcRenderer.on("effects-lib-play", (event, id) => callback(id)),
    onEffectsLibStop: (callback) => ipcRenderer.on("effects-lib-stop", () => callback()),
    onSetupGotoPanel: (callback) => ipcRenderer.on("setup-goto-panel", (event, panelId) => callback(panelId)),

    // ---- MIDI-MASTER-01 Phase 1: trạng thái MIDI THẬT phía main process (easymidi) ----
    // Dùng bởi ui/js/midiHealth.js để hợp nhất với trạng thái Web MIDI phía renderer.
    getMainMidiHealth: () => ipcRenderer.invoke("midi-health"),

    // ---- TASK B2: Auto Connect (discover + ensure AUTO MENU AI + connect) + Verification thật ----
    autoConnectMidi: (opts) => ipcRenderer.invoke("midi-auto-connect", opts),
    verifyMidiOutput: () => ipcRenderer.invoke("midi-verify"),
    // ---- MIDI-RECOVERY-01: cổng thật của backend (easymidi) + đường gửi Note/CC có thẩm quyền ----
    listMidiPorts: () => ipcRenderer.invoke("midi-list-ports"),
    sendMidiMessage: (msg) => ipcRenderer.invoke("midi-send", msg),

    // ---- TASK A71: trạng thái RUNTIME của SYSTEM_AUDIO (sống trong renderer cửa sổ chính) cần
    // phản ánh sang cửa sổ Setup — main.js chỉ đóng vai trò relay + cache lại giá trị mới nhất. ----
    reportSystemAudioState: (state) => ipcRenderer.send("system-audio-state-changed", state),
    onSystemAudioStateChange: (callback) => ipcRenderer.on("system-audio-state-changed", (event, state) => callback(state)),
    getSystemAudioState: () => ipcRenderer.invoke("get-system-audio-state"),
    // TASK B72 (gộp B72+B72.1) — MIC: cùng cơ chế IPC 2 chiều với SYSTEM_AUDIO (A71) ở trên,
    // chỉ đổi tên kênh, KHÔNG đụng 3 dòng trên.
    reportMicState: (state) => ipcRenderer.send("mic-state-changed", state),
    onMicStateChange: (callback) => ipcRenderer.on("mic-state-changed", (event, state) => callback(state)),
    getMicState: () => ipcRenderer.invoke("get-mic-state"),
    // TASK B72 — Audio Output: cùng cơ chế IPC 2 chiều, kênh riêng.
    reportOutputState: (state) => ipcRenderer.send("output-state-changed", state),
    onOutputStateChange: (callback) => ipcRenderer.on("output-state-changed", (event, state) => callback(state)),
    getOutputState: () => ipcRenderer.invoke("get-output-state"),

    // ---- TASK A52: Admin Authentication (mở khoá khu vực "AI 🔒" trong Setup) ----
    // Xác thực THẬT xảy ra ở main process (core/shared/AdminAuth.js) — hàm này chỉ relay
    // qua IPC, không tự so sánh password ở renderer.
    adminAuthVerify: (password) => ipcRenderer.invoke("admin-auth-verify", password),
    adminAuthChangePassword: (currentPassword, newPassword) =>
        ipcRenderer.invoke("admin-auth-change-password", { currentPassword, newPassword }),
});
